#!/usr/bin/env bash

# . ~/catkin_ws/devel/setup.bash
source ~/group_1_ws/devel/setup.bash

# Run the example node
echo "Launching ARIAC nodes"

roslaunch project_ariac project_ariac.launch
