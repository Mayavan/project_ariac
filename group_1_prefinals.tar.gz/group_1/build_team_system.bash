#!/usr/bin/env bash

echo "Preparing for Group 1"
# Prepare ROS
. /opt/ros/${ROS_DISTRO}/setup.bash

# Install the necessary dependencies for getting the team's source code
# Note: there is no need to use `sudo`.
apt-get update
apt-get install -y git

apt-get install -y ariac

apt-get install -y ros-kinetic-moveit-core \
                  ros-kinetic-moveit-kinematics \
                  ros-kinetic-moveit-ros-planning \
                  ros-kinetic-moveit-ros-move-group \
                  ros-kinetic-moveit-planners-ompl \
                  ros-kinetic-moveit-ros-visualization \
                  ros-kinetic-moveit-simple-controller-manager

echo "Movit dependencies installed"

mkdir -p ~/moveit_ws/src
cd ~/moveit_ws/src

git clone https://github.com/osrf/universal_robot -b ariac_ur10_moveit_config_kinetic

cd ~/moveit_ws/
catkin_make install
source install/setup.bash

cd ..

# Create a catkin workspace
mkdir -p ~/group_1_ws/src
# Fetch the source code for our team's code
cd ~/group_1_ws/src
echo "start project_ariac"
git clone https://github.com/raviBhadeshiya/project_ariac.git
cd ~/group_1_ws/

catkin_make
